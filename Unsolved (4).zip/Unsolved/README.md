# **Instructions**

* For the table favorite_foods...

  * Create the column "food" which can take in a 50 character string and cannot be NULL
  * Create the column "score" which can take in an integer

* For the table favorite_songs...

  * Create the column "song" which can take in a 100 character string and cannot be NULL
  * Create the column "artist" which can take in a 50 character string
  * Create the column "score" which can take in an integer

* For the table favorite_movies...

  * Create the column "film" which can take in a string and cannot be NULL
  * Create the column "five_times" which can take in a boolean
  * create the column "score" which can take in an integer

* BONUS: Go online and look into how one might go about adding data into a table.
